from flask import Flask, request, jsonify
import sqlite3
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import schedule
import time

app = Flask(__name__)


def email_event_data():
    connection = sqlite3.connect("employee_events.db")
    cursor = connection.cursor()
    query = """
    SELECT employee.employee_email, event_name, employee.employee_name
    FROM employee
    INNER JOIN events ON employee.employee_id = events.employee_id
    WHERE strftime('%m-%d', event_date) = strftime('%m-%d', 'now')
    """
    cursor.execute(query)
    bday_mails = cursor.fetchall()
    bday_dict = {}
    for bday in bday_mails:
        bday_dict[bday[0]] = (bday[1], bday[2])
    cursor.close()
    connection.close()
    return bday_dict


def specific_event_list(email_event):
    birthday = []
    bnames = []
    work_anniversary = []
    wnames = []

    for i in email_event:
        if email_event[i][0] == "birthday":
            birthday.append(i)
            bnames.append(email_event[i][1])
        else:
            work_anniversary.append(i)
            wnames.append(email_event[i][1])

    return birthday, bnames, work_anniversary, wnames

def send_birthday_wish():
    try:
        email_event = email_event_data()
        birthday, bnames, _, _ = specific_event_list(email_event)

        smtp_server = "smtp.gmail.com"
        smtp_port = 587
        sender_email = "vivekbagul4@gmail.com"
        sender_password = 'momddcklpmmpreai'  # Replace with your email password

        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, sender_password)

        for recipient_email in birthday:
            message = f"""You're incredible {bnames[birthday.index(recipient_email)]}\nOur greatest wish is to be more like you.\nWISH YOU A VERY HAPPY BIRTHDAY!!!.\nEnjoy your day...."""
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['Subject'] = "WISH YOU A VERY HAPPY BIRTHDAY"
            msg.attach(MIMEText(message, 'plain'))
            msg['To'] = recipient_email
            server.sendmail(sender_email, recipient_email, msg.as_string())

            server.quit()
        return jsonify({"message": "Birthday emails sent successfully"})
    except Exception as e:
        return jsonify({"error": str(e)})


def send_work_anniversary_wish():
    try:
        email_event = email_event_data()
        _, _, work_anniversary, wnames = specific_event_list(email_event)

        smtp_server = "smtp.gmail.com"
        smtp_port = 587
        sender_email = "vivekbagul4@gmail.com"
        sender_password = 'momddcklpmmpreai'  # Replace with your email password

        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, sender_password)

        for recipient_email in work_anniversary:
            message = f"""You're incredible {wnames[work_anniversary.index(recipient_email)]},\nOur greatest wish is to be more like you.\nWISH YOU A VERY HAPPY WORK ANNIVERSARY!!!."""
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['Subject'] = "WISH YOU A VERY HAPPY WORK ANNIVERSARY"
            msg.attach(MIMEText(message, 'plain'))
            msg['To'] = recipient_email
            server.sendmail(sender_email, recipient_email, msg.as_string())

        server.quit()
        return jsonify({"message": "Work anniversary emails sent successfully"})
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/', methods=['GET', 'POST'])
def send_wishes():
    try:
        send_birthday_wish()
        send_work_anniversary_wish()
        return jsonify({"message": "Birthday and work anniversary emails sent successfully"})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    schedule.every().day.at("11:06").do(send_birthday_wish)
    schedule.every().day.at("11:06").do(send_work_anniversary_wish)
    app.run()

        # import sqlite3
# import smtplib
# from email.mime.text import MIMEText
# from email.mime.multipart import MIMEMultipart
# import schedule
# import time
# connection = sqlite3.connect("employee_events.db")
# cursor = connection.cursor()
# def email_event_data():
#     query = """
#     SELECT employee.employee_email,event_name,employee.employee_name
#     FROM employee
#     INNER JOIN events ON employee.employee_id = events.employee_id
#     WHERE strftime('%m-%d', event_date) = strftime('%m-%d', 'now')
#     """
#     cursor.execute(query)
#     bday_mails = cursor.fetchall()
#     bday_dict= {}
#     for bday in bday_mails:
#         bday_dict[bday[0]]=(bday[1],bday[2])
#     cursor.close()
#     connection.close()
#     return bday_dict
# email_event=email_event_data()
# print(email_event)
# def specific_event_list(email_event):
#     global birthday
#     global work_anniversary
#     global bnames
#     global wnames
#     birthday=[]
#     bnames=[]
#     wnames=[]
#     work_anniversary=[]
#     for i in email_event:
#         if email_event[i][0]=="birthday":
#             birthday.append(i)
#             bnames.append(email_event[i][1])
#         else:
#             work_anniversary.append(i)
#             wnames.append(email_event[i][1])
# specific_event_list(email_event)
# print("birthday", birthday)
# print("work_anniversary", work_anniversary)
# print("bnames", bnames)
# print("wnames", wnames)
# def send_bday_wish():
#     try:
#         smtp_server = "smtp.gmail.com"
#         smtp_port = 587
#         sender_email = "vivekbagul4@gmail.com"
#         sender_password = 'momddcklpmmpreai'
#         recipient_emails = birthday
#         subject = "WISH YOU A VERY HAPPY BIRTHDAY"
#         server = smtplib.SMTP(smtp_server, smtp_port)
#         server.starttls()
#         server.login(sender_email, sender_password)
#         p=0
#         for recipient_email in recipient_emails:
#             message = f"""You're incredible {bnames[p]}\n.Our greatest wish is to be more like you.\nWISH YOU A VERY HAPPY BIRTHDAY!!!.\nEnjoy your day...."""
#             msg = MIMEMultipart()
#             msg['From'] = sender_email
#             msg['Subject'] = subject
#             msg.attach(MIMEText(message, 'plain'))
#             msg['To'] = recipient_email
#             print(recipient_email)
#             server.sendmail(sender_email, recipient_email, msg.as_string())
#             p=p+1
#         server.quit()
#         print(message)
#         print("Emails sent Successfully")
#     except Exception as e:
#         print(f'Error sending emails: {str(e)}')
# schedule.every().day.at("10:48").do(send_bday_wish)
#
# def send_work_anniversary_wish():
#     try:
#         smtp_server = "smtp.gmail.com"
#         smtp_port = 587
#         sender_email = "vivekbagul4@gmail.com"
#         sender_password = 'momddcklpmmpreai'
#         recipient_emails = work_anniversary
#         subject = "WISH YOU A VERY HAPPY WORK ANNIVERSARY"
#         server = smtplib.SMTP(smtp_server, smtp_port)
#         server.starttls()
#         server.login(sender_email, sender_password)
#         p = 0
#         for recipient_email in recipient_emails:
#             message = f"""You're incredible {wnames[p]},\nOur greatest wish is to be more like you.\nWISH YOU A VERY HAPPY WORK ANNIVERSARY!!!."""
#             msg = MIMEMultipart()
#             msg['From'] = sender_email
#             msg['Subject'] = subject
#             msg.attach(MIMEText(message, 'plain'))
#             msg['To'] = recipient_email
#             print(recipient_email)
#             server.sendmail(sender_email, recipient_email, msg.as_string())
#             p = p + 1
#         server.quit()
#         print(message)
#         print("Emails sent Successfully")
#     except Exception as e:
#         print(f'Error sending emails: {str(e)}')
# schedule.every().day.at("10:48").do(send_work_anniversary_wish)
#
# while True:
#     schedule.run_pending()
#     time.sleep(1)
