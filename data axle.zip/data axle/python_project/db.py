import sqlalchemy
from sqlalchemy import create_engine
from sqlalchemy import DATETIME, Table, Column, Integer,Boolean, String, ForeignKey,func,and_
from sqlalchemy import select
from sqlalchemy.sql import text
from sqlalchemy.orm import Session
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import relationship
Base = declarative_base()

class Employee(Base):
    __tablename__ = 'employee'
    employee_id = Column(Integer, primary_key=True )
    employee_name = Column(String,nullable=False)
    employee_email = Column(String,nullable=False,unique=True)

class Events(Base):
    __tablename__ = 'events'
    event_id=Column(Integer, autoincrement=True,primary_key=True)
    employee_id = Column(Integer, ForeignKey("employee.employee_id"), default=False)
    event_name = Column(String,nullable=False)
    event_date=Column(String,nullable=False)
    listtitle=Column(String,nullable=False)



engine = create_engine("sqlite:///./employee_events.sqlite3")

print("hello world")
